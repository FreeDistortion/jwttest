package com.example.jwttest.jwt.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class JwtTestController {
    @GetMapping("/test")
    public String test() {
        return "Configuration Test";
    }

    @PostMapping("/filtertest")
    public String filtertest() {
        return "Test done.";
    }

    @GetMapping("/api/test")
    public String apitest() {
        return "Config Test(/api/test)";
    }

}
