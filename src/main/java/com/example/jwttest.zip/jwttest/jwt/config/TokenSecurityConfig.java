package com.example.jwttest.jwt.config;

import com.example.jwttest.jwt.filter.JwtAuthenticationFilter;
import com.example.jwttest.jwt.filter.MyTestFilter1;
import com.example.jwttest.jwt.security.MyAuthProvider;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.security.servlet.PathRequest;
import org.springframework.context.annotation.Bean;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.filter.CorsFilter;
import org.springframework.web.filter.FormContentFilter;

@Slf4j
@EnableWebSecurity(debug = true)
@RequiredArgsConstructor
// spring security에 cross domain issue를 해결하기 위한 filter가 있어서 그걸 넣는 작업을 할 거임 ㅇㅇ
// 그게 뭐냐면
public class TokenSecurityConfig {

    private final CorsFilter corsFilter;
    private final UserDetailsService userDetailsService;

    public AuthenticationProvider authenticationProvider(){
        return new MyAuthProvider(userDetailsService,passwordEncoder());
    }

    @Bean
    public PasswordEncoder passwordEncoder(){
        return PasswordEncoderFactories.createDelegatingPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception {
        httpSecurity
//                .authorizeHttpRequests(authorizationManagerRequestMatcherRegistry -> authorizationManagerRequestMatcherRegistry
//                        .antMatchers("/test").permitAll()
//                        .anyRequest().permitAll())
                .sessionManagement(httpSecuritySessionManagementConfigurer -> httpSecuritySessionManagementConfigurer
                        // session을 사용하지 않겠다는 정의
                        .sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .addFilter(corsFilter)
//                .addFilterBefore(new MyFilter2(), CorsFilter.class)
//                .addFilterBefore(new MyFilter3(), MyFilter2.class)
//                .addFilterBefore(new MyFilter1(), MyFilter3.class)
                .addFilterAfter(new MyTestFilter1(), UsernamePasswordAuthenticationFilter.class)
                .addFilter(new JwtAuthenticationFilter())
                .csrf(csrfConfigurer -> csrfConfigurer
                        .disable())
                .formLogin(httpSecurityFormLoginConfigurer -> httpSecurityFormLoginConfigurer
                        .disable())
                .httpBasic(httpSecurityHttpBasicConfigurer -> httpSecurityHttpBasicConfigurer
                        .disable())
                .authorizeRequests(expressionInterceptUrlRegistry -> expressionInterceptUrlRegistry
                        .antMatchers("/api/**")
                        .access("hasRole('USER') or hasRole('ADMIN')")
                        .antMatchers("/admin/api/**")
                        .access("hasRole('ADMIN')")
                        .anyRequest().permitAll()
                )
        ;

        AuthenticationManagerBuilder authenticationManagerBuilder = httpSecurity.getSharedObject(AuthenticationManagerBuilder.class);
        authenticationManagerBuilder.authenticationProvider(authenticationProvider());

        return httpSecurity.build();
    }

    @Bean
    public WebSecurityCustomizer webSecurityCustomizer() {
        return web ->
                web.ignoring().requestMatchers(
                        PathRequest.toStaticResources().atCommonLocations()
                );
    }

}
